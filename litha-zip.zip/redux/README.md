# From here we will maintain the project's global storage 

This folder contains Two types of files / folders

1. Actions:
    - all action files for the redux storage;
    - one actionType file to maintain the action type of redux

2. Reducers: 
    - this will have multiple reducers ( files for separate components );
    - one index file containing allReducer method which combines all reducers together 
