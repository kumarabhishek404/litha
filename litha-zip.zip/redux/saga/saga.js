/* eslint-disable no-unused-vars */
import { all, call, put, take, takeLatest } from "redux-saga/effects";

// eslint-disable-next-line require-jsdoc
export function* serverLogin(action) {}
