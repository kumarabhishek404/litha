export const APP_TITLE = "APP_TITLE";
export const THEME = "THEME";
export const LANG = 'LANG';

export const IS_MOBILE = "IS_MOBILE";
export const INIT_LANGUAGE_CHANGE = "INIT_LANGUAGE_CHANGE";

export const SET_COUNTER = "SET_COUNTER";
export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';

export const DEMO_ACTION_TYPE = "DEMO_ACTION_TYPE";
