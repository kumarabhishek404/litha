
import { combineReducers } from 'redux';
import { DEFAULT_LANGUAGE } from '../../lib/config';
import { LanguageSet } from '../../translations/LanguageSet';
import globalReducer from './globalReducer';

export const initialState = {
    locale: LanguageSet[DEFAULT_LANGUAGE],
    language: DEFAULT_LANGUAGE
}

const rootReducer = combineReducers({
    store: globalReducer
})

export default rootReducer;