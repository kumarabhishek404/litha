// eslint-disable-next-line no-unused-vars
import * as actionTypes from "./actionTypes";
import { DEFAULT_LANGUAGE } from "../lib/config";
import { updateObject } from "../shared/utility";
import { LanguageSet } from "../translations/LanguageSet";

const languages = LanguageSet;

export const initialState = {
  language: DEFAULT_LANGUAGE,
  locale: LanguageSet[DEFAULT_LANGUAGE],
};

const updateLocale = (state, action) => {
  return updateObject(state, {
    locale: languages[action.selectedLang],
    language: action.selectedLang,
  });
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.INIT_LANGUAGE_CHANGE:
      return updateLocale(state, action);
      
    default:
      return state;
  }
};

export default reducer;
