import React from 'react'
import TextField from '../../components/input/index';
import Button from '../../components/buttons/index'
import CustomCheckbox from '../../components/checkbox';

function LogIn() {
    return (
        <div className='login p-3 d-flex justify-content-center align-items-center'>
            <div className='login__container d-flex'>
                <div className='login__image'>
                    <img src='https://source.unsplash.com/WEQbe2jBg40/414x512' />
                </div>
                <div className='form__section  border d-flex flex-column align-items-center'>
                    <h2>Login </h2>
                    <form className='form'>
                        <div className='input__box mb-3'>
                            <p>Email</p>
                            <TextField
                                className="input__textField mt-2"
                                type='email'
                                name="email"
                                id='email'
                                placeholder='Email' />
                        </div>
                        <div className='input__box mb-3'>
                            <p>Password</p>
                            <TextField
                                className="input__textField mt-2"
                                type='password'
                                name="password"
                                id='password'
                                placeholder='Password' />
                        </div>
                        <div className='remember__forgetPass d-flex justify-content-between px-2'>
                            <CustomCheckbox
                                label="Remember Me"
                                className='m-0 p-0'
                            />
                            <a className='m-0 p-0'>Forget Password</a>
                        </div>
                        <Button
                            type='submit'
                            className='login_btn'>
                            LogIn
                        </Button>
                        <div className='other_links text-right'>
                            <a className='p-0 m-0 mx-1' href='/registration'>create an account</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default LogIn;
