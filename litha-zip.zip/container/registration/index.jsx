import React, { useState } from 'react'
import TextField from '../../components/input/index';
import Button from '../../components/buttons/index'
// import CustomCheckbox from '../../components/checkbox';
import UsernameEmailPassword from './inputs/user_email_passwoed';
import Mobile from './inputs/mobile';

function SignUp() {

    const [count, setCount] = useState(0)

    const incrementCountHandler = () => {
        setCount(prevCount => prevCount + 1)
    }

    const decrementCountHandler = () => {
        setCount(prevCount => prevCount - 1)
    }

    const renderComp = (count) => {
        switch (count) {
            case 0:
                return <UsernameEmailPassword />;
            case 1:
                return <Mobile />;
            // case 2:
            //     return <EmailComp />;
            // case 3:
            //     return <MobileNumComp />;
            // case 4:
            //     return <DOBComp />;
            // case 5:
            //     return <PasswordComp />;
            default:
                return;
        }
    };

    return (
        <div className='login p-3 d-flex justify-content-center align-items-center'>
            <div className='login__container d-flex'>
                <div className='login__image'>
                    <img src='https://images.pexels.com/photos/1544880/pexels-photo-1544880.jpeg' />
                </div>
                <div className='form__section d-flex flex-column align-items-center'>
                    {count ? <i className="fa fa-arrow-left back__arrow" onClick={decrementCountHandler} aria-hidden="true"></i> : <></>}
                    <h2>Register</h2>
                    <div className='other_links text-right d-flex'>
                        <p className='p-0 m-0 mx-1'>already have an acount</p>
                        <a className='' href='/signIn'>login</a>
                    </div>
                    <form className='form'>
                        {renderComp(count)}

                    </form>
                    <Button
                        type='submit'
                        onClick={incrementCountHandler}
                        className='register__btn button'>
                        {count == 0 ? 'Next' : 'Register'}
                    </Button>
                </div>
            </div>
        </div>
    )
}

export default SignUp;

