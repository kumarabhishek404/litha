import React from 'react'
import TextField from '../../../components/input/index';
import RadioButtonsGroup from '../../../components/gender/radio-button-group';
import { FormControlLabel, Radio } from '@material-ui/core';

function UsernameEmailPassword() {
    return (
        <>
            <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>First Name</p>
                <TextField
                    className="input__textField mt-1"
                    type='text'
                    name="fname"
                    id='fname'
                    placeholder='First Name' />
            </div>
            <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>Last Name</p>
                <TextField
                    className="input__textField mt-1"
                    type='text'
                    name="lname"
                    id='lname'
                    placeholder='Last Name' />
            </div>
            <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>Gender</p>
                {/* <Gender /> */}
                
                <RadioButtonsGroup
                    radioLabelClass="m-0 white post_label mb-3"
                    radioClass="text-muted"
                    formLabelClass={`
                            height: 30px;
                          `}
                    labelPlacement="start"
                    value=''
                    onRadioChange={(val) => {
                        postToSelectHandler(val);
                    }}
                    buttonGroupData={[
                        { value: 1, label: "Story" },
                        { value: 2, label: "Feed" },
                    ]}></RadioButtonsGroup>
            </div>


        </>
    )
}

export default UsernameEmailPassword;