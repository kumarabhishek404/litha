import React from 'react'
import TextField from '../../../components/input/index';

function Mobile() {
    return (
        <>
             <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>Email</p>
                <TextField
                    className="input__textField mt-1"
                    type='email'
                    name="email"
                    id='email'
                    placeholder='Email' />
            </div>
            <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>Password</p>
                <TextField
                    className="input__textField mt-1"
                    type='password'
                    name="password"
                    id='password'
                    placeholder='Password' />
            </div>
            <div className='input__box mb-1'>
                <p className='m-0 p-0 mt-3'>Confirm Password</p>
                <TextField
                    className="input__textField mt-1"
                    type='password'
                    name="confirmPassword"
                    id='confirmPassword'
                    placeholder='Confirm Password' />
            </div>
        </>
    )
}

export default Mobile;