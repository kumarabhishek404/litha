import React from 'react'

const Input = (props) => {
    const {
        type="text",
        value="",
        onClick,
        className="",
        style={},
        name,
        id,
        placeholder,
        ...otherProps
     } = props;
    return (
        <input 
            type={type} 
            name={name || "text-input"} 
            id={id || Math.random.toString()}
            value={value}
            onClick={onClick}
            className={`cus_class ${className || ""}`}
            placeholder={placeholder || 'Enter something'}
            {...otherProps}
            />
    )
}

export default Input
