import React from 'react'
import { TextField } from '@material-ui/core'

const CustomTextField = () => {
    return (
        <div>
            <TextField id="standard-basic" label="Standard" />
        </div>
    )
}

export default CustomTextField
