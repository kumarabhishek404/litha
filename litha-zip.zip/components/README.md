# This directory contains all small small components here

- all components which are using in pages section or container section
