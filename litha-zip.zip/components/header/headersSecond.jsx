import React from 'react'
// import DropdownMenu from '../Dropdown/dropdown
import DropdownMenu from '../Dropdown/dropdownMenu'


const Header = () => {
  const handleClick = (event) => {
    // console.log('event', event)

  }
  const aboutItems = [
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "About Litha Labs",
      onClick: handleClick
    },
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "Litha Psychology",
      onClick: handleClick
    },
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "Litha Technology",
      onClick: handleClick
    }
  ]
  const conversationItems = [
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "About Litha Labs",
      onClick: handleClick
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Litha Psychology",
      onClick: handleClick
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Litha Technology",
      onClick: handleClick
    }
  ]

  
  return (
    <nav className='navbar__second d-flex justify-content-between align-items-center p-5'>
      <div className='px-5'>
        <a>
          Litha Labs
        </a>

      </div>
      <div className=''>
        <ul className='d-flex justify-content-between p-0 m-0'>

          <li>
            <DropdownMenu button="About" menuItems={aboutItems} />
          </li>

          {/* <li>
            <DropdownWithIcon button="Conversations" menuItems={conversationItems} />
          </li> */}

          <li>Conversations</li>
          <li>Assessors</li>
          <li>Orienters</li>
          <li>Account</li>
        </ul>
      </div>
    </nav>
  )
}

export default Header
