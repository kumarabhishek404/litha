import React from 'react'
import DropdownMenu from '../Dropdown/dropdownMenu';
import { open_drawer } from '../../lib/global';
import Route from 'next/router';
import Link from 'next/link';

const Header = () => {
  const handleClick = (event) => {
    Route.push(event)

  }
  const aboutItems = [
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "About Litha Labs",
      onClick: () => handleClick("about_litha_labs")
    },
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "Litha Psychology",
      onClick: () => handleClick("litha_psychology")
    },
    {
      icon: "",
      iconWidth: "",
      iconHeight: "",
      label: "Litha Technology",
      onClick: () => handleClick("litha_technology")
    }
  ]
  const conversationItems = [
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "About Convrsationers",
      onClick: () => handleClick("about_conversationers")
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Bunty",
      onClick: () => handleClick("bunty")
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Dreams Expert",
      onClick: () => handleClick("about_dreams_expert")
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Knowledge Expert",
      onClick: () => handleClick("about_knowledge_expert")
    }
  ]

  const assessorsItems = [
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "About Assessors",
      onClick: () => handleClick("about_assessors")
    },
    {
      icon: <i className="fa fa-comments-o" aria-hidden="true"></i>,
      iconWidth: "",
      iconHeight: "",
      label: "Working With Assessors",
      onClick: () => handleClick("working_with_assessors")
    }
  ]

  const orientersItems = [
    {
      icon: '',
      iconWidth: "",
      iconHeight: "",
      label: "About Human Orienters",
      onClick: () => handleClick("about_human_orienters")
    },
    {
      icon: '',
      iconWidth: "",
      iconHeight: "",
      label: "Working With Orienters",
      onClick: () => handleClick("working_with_orienters")
    }
  ]

  const accountItems = [
    {
      icon: '',
      iconWidth: "",
      iconHeight: "",
      label: "Sign In",
      onClick: () => handleClick("signIn")
    }
  ]


  return (
    <nav className='text-light navbar d-flex justify-content-between align-items-center p-5'>
      <div className="container">
        <div className=''>
          <Link href="/">
            <a>Litha Labs</a>
          </Link>
        </div>
        <div onClick={() => { open_drawer("SIDEBAR", "", "left") }} className='menu__bar__icon'>
          <i className="fa fa-bars" aria-hidden="true"></i>
        </div>
        <div className='navbar__links'>
          <ul className='d-flex justify-content-between p-0 m-0'>

            <li>
              <DropdownMenu button="About" menuItems={aboutItems} />
            </li>
            <li>
              <DropdownMenu button="Conversationers" menuItems={conversationItems} />
            </li>
            <li>
              <DropdownMenu button="Assessors" menuItems={assessorsItems} />
            </li>
            <li>
              <DropdownMenu button="Orienters" menuItems={orientersItems} />
            </li>
            <li>
              <DropdownMenu button="Account" menuItems={accountItems} />
            </li>

          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Header
