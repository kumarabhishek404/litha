import React from 'react'
import Headers from '../header/headers';
import Footer from '../footer/footer';
import HeadersSecond from '../header/headersSecond';

// import Widget from 'rasa-webchat'

// import ChatbotWidget from '../../container/ChatbotWidget';
// import Page from '../../container/ChatbotWidget/index.html';
// var htmlDoc = {__html: Page}
// var __html = require('../../container/ChatbotWidget/index.html') 




const Layout = (props) => {


    return (
        <React.Fragment>
            <div className=''>
                <Headers />
                <div id="home-body" className="home-body">
                    {props.children}
                </div>
                <Footer />
            </div>
            {/* <div dangerouslySetInnerHTML={htmlDoc}></div> */}
            {/* <Widget
            initPayload={"/get_started"}
            socketUrl={""}
            socketPath={"/socket.io/"}
            customData={{ "language": "en" }} 
            title={"Title"}
        /> */}
        </React.Fragment>
    )
}

export default Layout;
