// This function is used to wrap the children into one,
// use this as a wrapper in your components and containers

const Wrapper = (props) => props.children;
export default Wrapper;
