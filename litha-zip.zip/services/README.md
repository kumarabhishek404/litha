# This directory contains all service files for the website

    this can have all api calls for different components in separate files