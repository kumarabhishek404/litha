import React from 'react'

const UserPage = () => {
    return (
        <div>
            Users
        </div>
    )
}

export default UserPage
