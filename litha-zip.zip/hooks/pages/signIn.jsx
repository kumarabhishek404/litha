import dynamic from 'next/dynamic';
import React from 'react';
import Image from '../components/Images/Image';
import Layout from '../components/Layout/index';
import useLang from '../hooks/useLang';
import { HOME_PAGE_BG_IMAGE } from '../lib/config';

const Head = dynamic(() => import("../components/html/head"), { ssr: false });

function SignIn({ imageSrc, heading, subHeading }) {
    const [lang] = useLang()
    return (
        <Layout>
            <Head pageTitle="SignIn" />
            <div className='d-flex flex-column align-items-center'>
                <div className='landing__section'>
                    <Image
                        className='landing__image position-relative'
                        src={HOME_PAGE_BG_IMAGE}
                        width='100%'
                        height='100%' />

                    <div className='landing__overlay'></div>

                    <div className='landing__heading position-absolute w-100 text-center text-light'>
                        <h1>{lang.signIn}</h1>
                        <h2>Work In Progress!!!</h2>
                    </div>
                </div>
            </div>
        </Layout>
    )
}

export default SignIn;
