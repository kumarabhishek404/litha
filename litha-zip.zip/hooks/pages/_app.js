
import "bootstrap/dist/css/bootstrap.min.css";
import "../public/css/index.css"
import { Provider, useSelector } from "react-redux";
import LangContext from "../context/language";
import NetworkDetector from "../hoc/NetworkDetector";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import dynamic from "next/dynamic";
import withRedux from "next-redux-wrapper";
import createStore from "../redux/store";

const DialogHoc = dynamic(() => import("../hoc/dialogHoc"), {ssr: false});
const DrawerHoc = dynamic(() => import("../hoc/drawerHoc"), {ssr: false});

const theme = createMuiTheme({
  palette: {
    primary: {
      main: "#1bb1e6",
    },
  },
});

const MyApp = (props) => { 

    const {Component, pageProps, store} = props;
    return (
      <>
        <Provider store={store}>
          <LangContext.Provider
            value={{
              langCode: (store.getState() && store.getState().language) || "en",
              lang: store.getState().locale || {},
            }}
          >
            <MuiThemeProvider theme={theme}>
              <meta name="apple-mobile-web-app-capable" content="yes" />
              <meta name='viewport' content='minimum-scale=1, initial-scale=1, width=device-width, shrink-to-fit=no, viewport-fit=cover' />
              <DialogHoc></DialogHoc>
              <DrawerHoc></DrawerHoc>

              <Component {...pageProps} />
            </MuiThemeProvider>
          </LangContext.Provider>
        </Provider>
      </>
    );
}

MyApp.getInitialProps = async ({ Component, ctx }) => {
  let pageProps = {};
  if (Component && Component.getInitialProps) {
    pageProps = await Component.getInitialProps({ ctx });
  }

  let isMobile = false;
  console.log('Mobile', Mobile)
  // isMobile = await detectDevice(ctx);
  // ctx.store.dispatch(setMobileView(isMobile));

  // ctx.store.dispatch(setLanguage(lan));
 
  return { pageProps, isMobile };
};

export default withRedux(createStore)(
  NetworkDetector(MyApp)
);