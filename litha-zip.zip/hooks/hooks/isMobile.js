// import React from 'react';
// import { useSelector } from "react-redux";

const isMobile = () => {
  // const mobileView = useSelector((state) => state.isMobile);
  return [true];
};

export default isMobile;
