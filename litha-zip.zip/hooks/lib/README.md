# This directory contains all global stuffs used in the project 

1. Configs:
    - this file contains all app configurations globaly:
        - API base url

2. Sessions:
    - this file contains all session storage for the app ( we are using localstarge here ).

3. Requests:
    - in this file we will define all api request methods for global use 

