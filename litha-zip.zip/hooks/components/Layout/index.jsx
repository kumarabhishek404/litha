import React from 'react'
import Headers from '../header/headers';
import Footer from '../footer/footer';
import HeadersSecond from '../header/headersSecond';


const Layout = (props) => {


    return (
        <React.Fragment>
            <div className=''>
            <Headers />
            <div id="home-body" className="home-body">
                {props.children}
            </div>
            <Footer />
            </div>
        </React.Fragment>
    )
}

export default Layout;
