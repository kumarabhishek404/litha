import dynamic from 'next/dynamic';
import React from 'react';
import Image from '../components/Images/Image';
import Layout from '../components/Layout/index';
import useLang from '../hooks/useLang';
import { HOME_PAGE_BG_IMAGE } from '../lib/config';
import Login from '../container/login/index';

const Head = dynamic(() => import("../components/html/head"), { ssr: false });

function SignIn({ imageSrc, heading, subHeading }) {
    const [lang] = useLang()
    return (
        <>
            <Head pageTitle="SignIn" />
            <Login />
        </>
    )
}

export default SignIn;
